#ifndef _MAIN_H_
#define _MAIN_H_

#include <REGX52.H>

#define FREQ_OSC 11059200ul

#endif