#ifndef _Delay_H_
#define _Delay_H_

void Delay_ms(unsigned int t);

#endif